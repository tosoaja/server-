
import axios from 'axios';

const BOT_TOKEN = '7784863108:AAFYgdlWwaGRsdTMvaTqc15Tp617jFaK3is';
const CHAT_ID = '-1002693052458';
let lastUpdateId = 0;

export default async function handler(req, res) {
  try {
    const { data } = await axios.get(`https://api.telegram.org/bot${BOT_TOKEN}/getUpdates`, {
      params: { offset: lastUpdateId + 1 }
    });

    const messages = [];

    for (const update of data.result) {
      lastUpdateId = update.update_id;
      const msg = update.message;
      if (msg && msg.chat.id.toString() === CHAT_ID && msg.text) {
        messages.push({ from: 'admin', text: msg.text });
      }
    }

    res.status(200).json({ messages });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
}
