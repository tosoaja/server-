
import axios from 'axios';

const BOT_TOKEN = '7784863108:AAFYgdlWwaGRsdTMvaTqc15Tp617jFaK3is';
const CHAT_ID = '-1002693052458';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).send('Method Not Allowed');

  const { name, message } = req.body;

  try {
    await axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      chat_id: CHAT_ID,
      text: `📩 *${name}*: ${message}`,
      parse_mode: 'Markdown'
    });
    res.status(200).json({ status: 'sent' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to send' });
  }
}
